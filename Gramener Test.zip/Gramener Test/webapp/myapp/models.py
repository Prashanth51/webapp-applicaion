from django.db import models
from django.contrib.auth.models import User
gender_list=(('M', 'Male'),('F','Femail'))
# Create your models here.
class Student(models.Model):
    Name=models.CharField(max_length=20)
    Age=models.IntegerField()
    Gender=models.CharField(max_length=1, null=True,blank=True,choices=gender_list)
    def __str__(self):
        return '%s' %(self.Name)
