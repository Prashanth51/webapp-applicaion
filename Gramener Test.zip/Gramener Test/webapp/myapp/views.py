from django.shortcuts import render
from django.http import HttpResponse
from .models import Student
from django.shortcuts import render, get_object_or_404,get_list_or_404
def base(request):
    return render(request,'index.html')

def Register(request):
    return render(request,'register.html')
def storeDetails(request):
    Name=request.POST['name']
    Age=request.POST['age']
    Gender=request.POST['gender']
    up=Student(Name=Name , Age= Age, Gender= Gender)
    up.save()
    sList = get_list_or_404(Student)
    return render(request, 'display.html', {'sList':sList})
