L1 = ['a', 'b', 'c',]
L2 = ['b','d']
L = []
for i in L2:
    if i not in L1:
        L.append(i)
print(L)
