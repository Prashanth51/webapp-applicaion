def common_Element(L1,L2):
    L1_set= (set(L1))
    L2_set= (set(L2)
    if(L1_set & L2_set):
        print(L1_set & L2_set )
    else:
        print("There are no common elements present in L1 & L2")
L1 = ['a', 'b', 'c']
L2 = ['b', 'd']
common_Element(L1,L2)
